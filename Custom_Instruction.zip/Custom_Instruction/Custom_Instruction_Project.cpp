#include <iostream>
using namespace std;
// Simulated custom instruction: Vector Dot Product + Bias
inline int VDOT3_BIAS(int a1, int a2, int a3,
                      int b1, int b2, int b3,
                      int bias) {
    return (a1 * b1 + a2 * b2 + a3 * b3) + bias;
}

int main() {
    // Input vectors and bias
    int a1 , a2 , a3 ;
    int b1 , b2 , b3;
    int bias ;

    cout<< "Enter a1 , a2 , a3 respectively :-"<<endl;
    cin>> a1 >> a2 >> a3 ;
    cout<< "Enter b1 , b2 , b3 respectively :-"<<endl;
    cin>> b1 >> b2 >> b3 ;
    cout<< "Enter bias:- "<<endl;
    cin>> bias;

    // Call the custom instruction
    int z = VDOT3_BIAS(a1, a2, a3, b1, b2, b3, bias);

    // Print the result
    cout << "Result (z): " << z << endl;

    return 0;

}
